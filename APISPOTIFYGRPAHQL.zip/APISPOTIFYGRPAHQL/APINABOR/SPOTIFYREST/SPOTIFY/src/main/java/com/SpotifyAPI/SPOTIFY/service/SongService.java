package com.SpotifyAPI.SPOTIFY.service;

import com.SpotifyAPI.SPOTIFY.entity.Playlist;
import com.SpotifyAPI.SPOTIFY.entity.Song;
import com.SpotifyAPI.SPOTIFY.repository.PlaylistRepository;
import com.SpotifyAPI.SPOTIFY.repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SongService {

    @Autowired
    private SongRepository songRepository;

    @Autowired
    private PlaylistRepository playlistRepository;

    public List<Song> findAll() {
        return songRepository.findAll();
    }

    public Optional<Song> findById(Long id) {
        return songRepository.findById(id);
    }

    public Optional<Song> findByIdWithPlaylists(Long id) {
        return songRepository.findByIdWithPlaylists(id);
    }

    public Song save(Song song) {
        return songRepository.save(song);
    }

    public Song update(Long id, Song songDetails) {
        return songRepository.findById(id)
                .map(song -> {
                    song.setNome(songDetails.getNome());
                    song.setArtista(songDetails.getArtista());
                    return songRepository.save(song);
                })
                .orElseThrow(() -> new RuntimeException("Música não encontrada com id: " + id));
    }

    public void deleteById(Long id) {
        // Remove a música de todas as playlists antes de deletar
        List<Playlist> playlists = playlistRepository.findByMusicaId(id);
        for (Playlist playlist : playlists) {
            playlist.getMusicas().removeIf(song -> song.getId().equals(id));
            playlistRepository.save(playlist);
        }
        songRepository.deleteById(id);
    }

    public List<Song> findByNome(String nome) {
        return songRepository.findByNomeContainingIgnoreCase(nome);
    }

    public List<Song> findByArtista(String artista) {
        return songRepository.findByArtistaContainingIgnoreCase(artista);
    }

    public List<Song> findByNomeAndArtista(String nome, String artista) {
        return songRepository.findByNomeContainingIgnoreCaseAndArtistaContainingIgnoreCase(nome, artista);
    }

    // REQUISITO: Listar playlists que contêm uma determinada música
    public List<Playlist> findPlaylistsBySongId(Long songId) {
        return playlistRepository.findByMusicaId(songId);
    }

    public boolean existsById(Long id) {
        return songRepository.existsById(id);
    }
}