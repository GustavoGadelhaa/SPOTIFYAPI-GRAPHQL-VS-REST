package com.SpotifyAPI.SPOTIFY.controller;

import com.SpotifyAPI.SPOTIFY.entity.User;
import com.SpotifyAPI.SPOTIFY.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import com.SpotifyAPI.SPOTIFY.entity.*;
import com.SpotifyAPI.SPOTIFY.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class GraphQLController {

    @Autowired private UserService userService;
    @Autowired private SongService songService;
    @Autowired private PlaylistService playlistService;

    // ========== QUERIES ==========

    // Usuários
    @QueryMapping
    public List<User> users() {
        return userService.findAll();
    }

    @QueryMapping
    public User user(@Argument Long id) {
        return userService.findById(id).orElse(null);
    }

    // Músicas
    @QueryMapping
    public List<Song> songs() {
        return songService.findAll();
    }

    @QueryMapping
    public Song song(@Argument Long id) {
        return songService.findById(id).orElse(null);
    }

    // Playlists
    @QueryMapping
    public List<Playlist> playlists() {
        return playlistService.findAll();
    }

    @QueryMapping
    public Playlist playlist(@Argument Long id) {
        return playlistService.findById(id).orElse(null);
    }

    // ========== MUTATIONS ==========

    // Usuários
    @MutationMapping
    public User createUser(@Argument String nome, @Argument Integer idade) {
        User user = new User(nome, idade);
        return userService.save(user);
    }

    @MutationMapping
    public User updateUser(@Argument Long id, @Argument String nome, @Argument Integer idade) {
        User userDetails = new User();
        if (nome != null) userDetails.setNome(nome);
        if (idade != null) userDetails.setIdade(idade);

        try {
            return userService.update(id, userDetails);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @MutationMapping
    public Boolean deleteUser(@Argument Long id) {
        if (userService.existsById(id)) {
            userService.deleteById(id);
            return true;
        }
        return false;
    }

    // Músicas
    @MutationMapping
    public Song createSong(@Argument String nome, @Argument String artista) {
        Song song = new Song(nome, artista);
        return songService.save(song);
    }

    @MutationMapping
    public Song updateSong(@Argument Long id, @Argument String nome, @Argument String artista) {
        Song songDetails = new Song();
        if (nome != null) songDetails.setNome(nome);
        if (artista != null) songDetails.setArtista(artista);

        try {
            return songService.update(id, songDetails);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @MutationMapping
    public Boolean deleteSong(@Argument Long id) {
        if (songService.existsById(id)) {
            songService.deleteById(id);
            return true;
        }
        return false;
    }

    // Playlists
    @MutationMapping
    public Playlist createPlaylist(@Argument String nome, @Argument Long usuarioId) {
        User user = new User();
        user.setId(usuarioId);

        Playlist playlist = new Playlist();
        playlist.setNome(nome);
        playlist.setUsuario(user);

        try {
            return playlistService.save(playlist);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @MutationMapping
    public Playlist updatePlaylist(@Argument Long id, @Argument String nome) {
        Playlist playlistDetails = new Playlist();
        if (nome != null) playlistDetails.setNome(nome);

        try {
            return playlistService.update(id, playlistDetails);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @MutationMapping
    public Boolean deletePlaylist(@Argument Long id) {
        if (playlistService.existsById(id)) {
            playlistService.deleteById(id);
            return true;
        }
        return false;
    }
}