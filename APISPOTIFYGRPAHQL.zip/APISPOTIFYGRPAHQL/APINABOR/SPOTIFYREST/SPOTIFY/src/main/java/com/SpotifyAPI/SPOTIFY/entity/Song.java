package com.SpotifyAPI.SPOTIFY.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "songs")
public class Song {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome da música é obrigatório")
    @Column(nullable = false)
    private String nome;

    @NotBlank(message = "Artista é obrigatório")
    @Column(nullable = false)
    private String artista;

    @ManyToMany(mappedBy = "musicas", fetch = FetchType.LAZY)
    private List<Playlist> playlists = new ArrayList<>();

    // Construtores
    public Song() {}

    public Song(String nome, String artista) {
        this.nome = nome;
        this.artista = artista;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }

    public List<Playlist> getPlaylists() { return playlists; }
    public void setPlaylists(List<Playlist> playlists) { this.playlists = playlists; }
}