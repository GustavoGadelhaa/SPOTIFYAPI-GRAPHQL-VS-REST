package com.SpotifyAPI.SPOTIFY.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "playlists")
public class Playlist {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome da playlist é obrigatório")
    @Column(nullable = false)
    private String nome;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private User usuario;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "playlist_musicas",
            joinColumns = @JoinColumn(name = "playlist_id"),
            inverseJoinColumns = @JoinColumn(name = "musica_id")
    )
    private List<Song> musicas = new ArrayList<>();

    // Construtores
    public Playlist() {}

    public Playlist(String nome, User usuario) {
        this.nome = nome;
        this.usuario = usuario;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public User getUsuario() { return usuario; }
    public void setUsuario(User usuario) { this.usuario = usuario; }

    public List<Song> getMusicas() { return musicas; }
    public void setMusicas(List<Song> musicas) { this.musicas = musicas; }

    // Métodos utilitários
    public void adicionarMusica(Song musica) {
        this.musicas.add(musica);
        musica.getPlaylists().add(this);
    }

    public void removerMusica(Song musica) {
        this.musicas.remove(musica);
        musica.getPlaylists().remove(this);
    }
}