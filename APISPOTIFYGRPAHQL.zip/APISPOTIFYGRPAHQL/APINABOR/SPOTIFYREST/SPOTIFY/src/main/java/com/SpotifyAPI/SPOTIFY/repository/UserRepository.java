package com.SpotifyAPI.SPOTIFY.repository;

import com.SpotifyAPI.SPOTIFY.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Buscar usuário por nome (case insensitive)
    List<User> findByNomeContainingIgnoreCase(String nome);

    // Buscar usuários por faixa etária
    List<User> findByIdadeBetween(Integer idadeMin, Integer idadeMax);

    // Buscar usuário com suas playlists (eager loading)
    @Query("SELECT u FROM User u LEFT JOIN FETCH u.playlists WHERE u.id = :id")
    Optional<User> findByIdWithPlaylists(@Param("id") Long id);
}