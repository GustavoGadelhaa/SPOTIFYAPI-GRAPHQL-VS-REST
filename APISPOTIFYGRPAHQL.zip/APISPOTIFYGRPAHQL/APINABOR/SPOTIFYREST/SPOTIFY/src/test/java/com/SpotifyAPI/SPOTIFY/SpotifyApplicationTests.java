package com.SpotifyAPI.SPOTIFY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
