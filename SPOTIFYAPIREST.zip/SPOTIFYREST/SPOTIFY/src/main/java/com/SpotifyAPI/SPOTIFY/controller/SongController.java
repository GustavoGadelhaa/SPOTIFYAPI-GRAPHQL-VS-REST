package com.SpotifyAPI.SPOTIFY.controller;

import com.SpotifyAPI.SPOTIFY.entity.Playlist;
import com.SpotifyAPI.SPOTIFY.entity.Song;
import com.SpotifyAPI.SPOTIFY.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/songs")
public class SongController {

    @Autowired
    private SongService songService;

    @GetMapping
    public List<Song> getAllSongs() {
        return songService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Song> getSongById(@PathVariable Long id) {
        Optional<Song> song = songService.findById(id);
        return song.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/with-playlists")
    public ResponseEntity<Song> getSongWithPlaylists(@PathVariable Long id) {
        Optional<Song> song = songService.findByIdWithPlaylists(id);
        return song.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Song createSong(@RequestBody Song song) {
        return songService.save(song);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Song> updateSong(@PathVariable Long id, @RequestBody Song songDetails) {
        try {
            Song updatedSong = songService.update(id, songDetails);
            return ResponseEntity.ok(updatedSong);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSong(@PathVariable Long id) {
        if (songService.existsById(id)) {
            songService.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/search")
    public List<Song> searchSongs(@RequestParam(required = false) String nome,
                                  @RequestParam(required = false) String artista) {
        if (nome != null && artista != null) {
            return songService.findByNomeAndArtista(nome, artista);
        } else if (nome != null) {
            return songService.findByNome(nome);
        } else if (artista != null) {
            return songService.findByArtista(artista);
        } else {
            return songService.findAll();
        }
    }

    // REQUISITO: Listar playlists que contêm uma determinada música
    @GetMapping("/{id}/playlists")
    public ResponseEntity<List<Playlist>> getPlaylistsBySong(@PathVariable Long id) {
        if (!songService.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        List<Playlist> playlists = songService.findPlaylistsBySongId(id);
        return ResponseEntity.ok(playlists);
    }
}