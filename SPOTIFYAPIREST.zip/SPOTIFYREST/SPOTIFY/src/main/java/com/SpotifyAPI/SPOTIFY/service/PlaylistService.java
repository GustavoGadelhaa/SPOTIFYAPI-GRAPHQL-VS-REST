package com.SpotifyAPI.SPOTIFY.service;

import com.SpotifyAPI.SPOTIFY.entity.Playlist;
import com.SpotifyAPI.SPOTIFY.entity.Song;
import com.SpotifyAPI.SPOTIFY.repository.PlaylistRepository;
import com.SpotifyAPI.SPOTIFY.repository.SongRepository;
import com.SpotifyAPI.SPOTIFY.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PlaylistService {

    @Autowired
    private PlaylistRepository playlistRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SongRepository songRepository;

    public List<Playlist> findAll() {
        return playlistRepository.findAll();
    }

    public Optional<Playlist> findById(Long id) {
        return playlistRepository.findById(id);
    }

    public Optional<Playlist> findByIdWithMusicas(Long id) {
        return playlistRepository.findByIdWithMusicas(id);
    }

    public Optional<Playlist> findByIdWithUsuarioAndMusicas(Long id) {
        return playlistRepository.findByIdWithUsuarioAndMusicas(id);
    }

    public Playlist save(Playlist playlist) {
        // Verifica se o usuário existe
        if (!userRepository.existsById(playlist.getUsuario().getId())) {
            throw new RuntimeException("Usuário não encontrado com id: " + playlist.getUsuario().getId());
        }
        return playlistRepository.save(playlist);
    }

    public Playlist update(Long id, Playlist playlistDetails) {
        return playlistRepository.findById(id)
                .map(playlist -> {
                    playlist.setNome(playlistDetails.getNome());
                    return playlistRepository.save(playlist);
                })
                .orElseThrow(() -> new RuntimeException("Playlist não encontrada com id: " + id));
    }

    public void deleteById(Long id) {
        playlistRepository.deleteById(id);
    }

    // REQUISITO: Listar playlists de um usuário específico
    public List<Playlist> findByUsuarioId(Long usuarioId) {
        return playlistRepository.findByUsuarioId(usuarioId);
    }

    public List<Playlist> findByUsuarioIdWithMusicas(Long usuarioId) {
        return playlistRepository.findByUsuarioIdWithMusicas(usuarioId);
    }

    // REQUISITO: Listar playlists que contêm uma música específica
    public List<Playlist> findByMusicaId(Long musicaId) {
        return playlistRepository.findByMusicaId(musicaId);
    }

    public List<Playlist> findByNome(String nome) {
        return playlistRepository.findByNomeContainingIgnoreCase(nome);
    }

    // Métodos para gerenciar músicas na playlist
    public Playlist adicionarMusica(Long playlistId, Long musicaId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new RuntimeException("Playlist não encontrada com id: " + playlistId));

        Song musica = songRepository.findById(musicaId)
                .orElseThrow(() -> new RuntimeException("Música não encontrada com id: " + musicaId));

        playlist.adicionarMusica(musica);
        return playlistRepository.save(playlist);
    }

    public Playlist removerMusica(Long playlistId, Long musicaId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new RuntimeException("Playlist não encontrada com id: " + playlistId));

        Song musica = songRepository.findById(musicaId)
                .orElseThrow(() -> new RuntimeException("Música não encontrada com id: " + musicaId));

        playlist.removerMusica(musica);
        return playlistRepository.save(playlist);
    }

    public boolean existsById(Long id) {
        return playlistRepository.existsById(id);
    }
}