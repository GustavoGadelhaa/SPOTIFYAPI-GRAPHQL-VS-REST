package com.SpotifyAPI.SPOTIFY.repository;

import com.SpotifyAPI.SPOTIFY.entity.Playlist;
import com.SpotifyAPI.SPOTIFY.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlaylistRepository extends JpaRepository<Playlist, Long> {

    // Buscar playlists por nome (case insensitive)
    List<Playlist> findByNomeContainingIgnoreCase(String nome);

    // Buscar playlists de um usuário específico (requisito do projeto)
    List<Playlist> findByUsuarioId(Long usuarioId);

    // Buscar playlists por usuário
    List<Playlist> findByUsuario(User usuario);

    // Buscar playlist com músicas (eager loading)
    @Query("SELECT p FROM Playlist p LEFT JOIN FETCH p.musicas WHERE p.id = :id")
    Optional<Playlist> findByIdWithMusicas(@Param("id") Long id);

    // Buscar playlist com usuário e músicas
    @Query("SELECT p FROM Playlist p LEFT JOIN FETCH p.usuario LEFT JOIN FETCH p.musicas WHERE p.id = :id")
    Optional<Playlist> findByIdWithUsuarioAndMusicas(@Param("id") Long id);

    // Buscar playlists que contêm uma música específica (requisito do projeto)
    @Query("SELECT p FROM Playlist p JOIN p.musicas m WHERE m.id = :musicaId")
    List<Playlist> findByMusicaId(@Param("musicaId") Long musicaId);

    // Buscar playlists por usuário com músicas
    @Query("SELECT p FROM Playlist p LEFT JOIN FETCH p.musicas WHERE p.usuario.id = :usuarioId")
    List<Playlist> findByUsuarioIdWithMusicas(@Param("usuarioId") Long usuarioId);
}