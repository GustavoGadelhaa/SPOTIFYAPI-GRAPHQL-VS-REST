# 🎵 Music Streaming API

Uma API RESTful para serviço de streaming de músicas desenvolvida em Spring Boot, implementando usuários, músicas e playlists.

## 🚀 Tecnologias

- **Java 17**
- **Spring Boot 3.2.0**
- **PostgreSQL** (Docker)
- **Spring Data JPA**
- **Maven**

## 📋 Pré-requisitos

- Java 17+
- Docker
- Maven

# 🎵 Music Streaming API


Uma API RESTful para serviço de streaming de músicas desenvolvida em Spring Boot.

# 🎵 Music Streaming API

Uma API RESTful para serviço de streaming de músicas desenvolvida em Spring Boot.

## 🧪 Exemplos de Uso com cURL

### 👥 Usuários

# Listar todos os usuários
curl -X GET http://localhost:8080/api/users

# Buscar usuário por ID
curl -X GET http://localhost:8080/api/users/1

# Criar novo usuário
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{"nome": "João Silva", "idade": 25}'

# Atualizar usuário
curl -X PUT http://localhost:8080/api/users/1 \
  -H "Content-Type: application/json" \
  -d '{"nome": "João Santos", "idade": 26}'

# Deletar usuário
curl -X DELETE http://localhost:8080/api/users/1

# Buscar usuários por nome
curl -X GET "http://localhost:8080/api/users/search?nome=João"

# Buscar usuários por faixa etária
curl -X GET "http://localhost:8080/api/users/age-range?min=20&max=30"




# Listar todas as músicas
curl -X GET http://localhost:8080/api/songs

# Buscar música por ID
curl -X GET http://localhost:8080/api/songs/1

# Criar nova música
curl -X POST http://localhost:8080/api/songs \
-H "Content-Type: application/json" \
-d '{"nome": "Bohemian Rhapsody", "artista": "Queen"}'

# Atualizar música
curl -X PUT http://localhost:8080/api/songs/1 \
-H "Content-Type: application/json" \
-d '{"nome": "Bohemian Rhapsody", "artista": "Queen Band"}'

# Deletar música
curl -X DELETE http://localhost:8080/api/songs/1

# Buscar músicas por artista
curl -X GET "http://localhost:8080/api/songs/search?artista=Queen"

# Buscar músicas por nome
curl -X GET "http://localhost:8080/api/songs/search?nome=Bohemian"

# Buscar playlists que contêm uma música
curl -X GET http://localhost:8080/api/songs/1/playlists




# Listar todas as playlists
curl -X GET http://localhost:8080/api/playlists

# Buscar playlist por ID
curl -X GET http://localhost:8080/api/playlists/1

# Criar nova playlist
curl -X POST http://localhost:8080/api/playlists \
-H "Content-Type: application/json" \
-d '{"nome": "Rock Classics", "usuario": {"id": 1}}'

# Atualizar playlist
curl -X PUT http://localhost:8080/api/playlists/1 \
-H "Content-Type: application/json" \
-d '{"nome": "Classic Rock"}'

# Deletar playlist
curl -X DELETE http://localhost:8080/api/playlists/1

# Playlists de um usuário
curl -X GET http://localhost:8080/api/playlists/user/1

# Músicas de uma playlist
curl -X GET http://localhost:8080/api/playlists/1/songs

# Playlists que contêm uma música
curl -X GET http://localhost:8080/api/playlists/song/1

# Adicionar música à playlist
curl -X POST http://localhost:8080/api/playlists/1/songs/1

# Remover música da playlist
curl -X DELETE http://localhost:8080/api/playlists/1/songs/1


# 1. Listar dados de todos os usuários
curl -X GET http://localhost:8080/api/users

# 2. Listar dados de todas as músicas
curl -X GET http://localhost:8080/api/songs

# 3. Listar playlists de um usuário específico
curl -X GET http://localhost:8080/api/playlists/user/1

# 4. Listar músicas de uma playlist específica
curl -X GET http://localhost:8080/api/playlists/1/songs

# 5. Listar playlists que contêm uma música específica
curl -X GET http://localhost:8080/api/playlists/song/1



## 🐳 Configuração do Banco de Dados

```bash
# Subir PostgreSQL com Docker
docker run --name spotifyapi \
  -e POSTGRES_DB=musicdb \
  -e POSTGRES_USER=root \
  -e POSTGRES_PASSWORD=postgres \
  -p 5432:5432 \
  -d postgres:15