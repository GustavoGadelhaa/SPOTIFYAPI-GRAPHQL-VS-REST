package com.SpotifyAPI.SPOTIFY.controller;


import com.SpotifyAPI.SPOTIFY.entity.Playlist;
import com.SpotifyAPI.SPOTIFY.entity.Song;
import com.SpotifyAPI.SPOTIFY.service.PlaylistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/playlists")
public class PlaylistController {

    @Autowired
    private PlaylistService playlistService;

    @GetMapping
    public List<Playlist> getAllPlaylists() {
        return playlistService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Playlist> getPlaylistById(@PathVariable Long id) {
        Optional<Playlist> playlist = playlistService.findById(id);
        return playlist.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/with-songs")
    public ResponseEntity<Playlist> getPlaylistWithSongs(@PathVariable Long id) {
        Optional<Playlist> playlist = playlistService.findByIdWithMusicas(id);
        return playlist.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/with-user-songs")
    public ResponseEntity<Playlist> getPlaylistWithUserAndSongs(@PathVariable Long id) {
        Optional<Playlist> playlist = playlistService.findByIdWithUsuarioAndMusicas(id);
        return playlist.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Playlist> createPlaylist(@RequestBody Playlist playlist) {
        try {
            Playlist savedPlaylist = playlistService.save(playlist);
            return ResponseEntity.ok(savedPlaylist);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Playlist> updatePlaylist(@PathVariable Long id, @RequestBody Playlist playlistDetails) {
        try {
            Playlist updatedPlaylist = playlistService.update(id, playlistDetails);
            return ResponseEntity.ok(updatedPlaylist);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlaylist(@PathVariable Long id) {
        if (playlistService.existsById(id)) {
            playlistService.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    // REQUISITO: Listar playlists de um usuário específico
    @GetMapping("/user/{userId}")
    public List<Playlist> getPlaylistsByUser(@PathVariable Long userId) {
        return playlistService.findByUsuarioId(userId);
    }

    @GetMapping("/user/{userId}/with-songs")
    public List<Playlist> getPlaylistsByUserWithSongs(@PathVariable Long userId) {
        return playlistService.findByUsuarioIdWithMusicas(userId);
    }

    // REQUISITO: Listar playlists que contêm uma música específica
    @GetMapping("/song/{songId}")
    public List<Playlist> getPlaylistsBySong(@PathVariable Long songId) {
        return playlistService.findByMusicaId(songId);
    }

    @GetMapping("/search")
    public List<Playlist> searchPlaylistsByName(@RequestParam String nome) {
        return playlistService.findByNome(nome);
    }

    // Gerenciar músicas na playlist
    @PostMapping("/{playlistId}/songs/{songId}")
    public ResponseEntity<Playlist> addSongToPlaylist(@PathVariable Long playlistId, @PathVariable Long songId) {
        try {
            Playlist playlist = playlistService.adicionarMusica(playlistId, songId);
            return ResponseEntity.ok(playlist);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{playlistId}/songs/{songId}")
    public ResponseEntity<Playlist> removeSongFromPlaylist(@PathVariable Long playlistId, @PathVariable Long songId) {
        try {
            Playlist playlist = playlistService.removerMusica(playlistId, songId);
            return ResponseEntity.ok(playlist);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // REQUISITO: Listar músicas de uma playlist específica
    @GetMapping("/{id}/songs")
    public ResponseEntity<List<Song>> getSongsByPlaylist(@PathVariable Long id) {
        Optional<Playlist> playlist = playlistService.findByIdWithMusicas(id);
        return playlist.map(p -> ResponseEntity.ok(p.getMusicas()))
                .orElse(ResponseEntity.notFound().build());
    }
}