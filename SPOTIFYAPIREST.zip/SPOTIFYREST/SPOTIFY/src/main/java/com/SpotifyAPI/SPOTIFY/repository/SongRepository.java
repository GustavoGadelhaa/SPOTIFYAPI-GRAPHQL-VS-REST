package com.SpotifyAPI.SPOTIFY.repository;

import com.SpotifyAPI.SPOTIFY.entity.Song;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SongRepository extends JpaRepository<Song, Long> {

    // Buscar músicas por nome (case insensitive)
    List<Song> findByNomeContainingIgnoreCase(String nome);

    // Buscar músicas por artista (case insensitive)
    List<Song> findByArtistaContainingIgnoreCase(String artista);

    // Buscar músicas por nome e artista
    List<Song> findByNomeContainingIgnoreCaseAndArtistaContainingIgnoreCase(String nome, String artista);

    // Buscar música com playlists que a contém (eager loading)
    @Query("SELECT s FROM Song s LEFT JOIN FETCH s.playlists WHERE s.id = :id")
    Optional<Song> findByIdWithPlaylists(@Param("id") Long id);

    // Buscar playlists que contêm uma música específica (requisito do projeto)
    @Query("SELECT s.playlists FROM Song s WHERE s.id = :songId")
    List<Object> findPlaylistsBySongId(@Param("songId") Long songId);
}